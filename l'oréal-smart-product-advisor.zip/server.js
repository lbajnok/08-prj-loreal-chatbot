import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const HOST = '0.0.0.0';

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/index.html', (_req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/style.css', (_req, res) => {
  res.sendFile(path.join(__dirname, 'style.css'));
});

app.get('/products.js', (_req, res) => {
  res.sendFile(path.join(__dirname, 'products.js'));
});

app.get('/script.js', (_req, res) => {
  res.sendFile(path.join(__dirname, 'script.js'));
});

app.use('/img', express.static(path.join(__dirname, 'img')));
app.use('/src/assets', express.static(path.join(__dirname, 'src/assets')));

app.listen(PORT, HOST, () => {
  console.log(`Server listening on http://${HOST}:${PORT}`);
});
