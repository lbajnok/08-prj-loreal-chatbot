// Catalog of real L'Oréal Group products across Skincare, Makeup, Haircare, and Fragrance.
// Linked directly from index.html so no module bundler is required.
const LOREAL_PRODUCTS = [
  {
    id: "loreal-hyaluronic-serum",
    brand: "L'Oréal Paris",
    name: "Revitalift 1.5% Pure Hyaluronic Acid Serum",
    category: "Skincare",
    price: 32,
    size: "1.0 fl oz",
    summary: "Deeply hydrates and visibly plumps fine lines with macro and micro hyaluronic acid.",
    description:
      "A fragrance-free, dermatologist-validated serum formulated with 0.5% macro hyaluronic acid for surface hydration and 1.0% micro hyaluronic acid to replenish deeper moisture.",
    keyBenefits: [
      "Intense 24-hour hydration without heavy residue",
      "Smooths skin texture and softens dehydration lines",
      "Layers cleanly beneath moisturizers and SPF"
    ],
    howToUse:
      "Apply 2 to 3 drops to damp, cleansed skin morning and evening before moisturizer.",
    image: "src/assets/images/loreal_hyaluronic_serum_1795372671409.jpg",
    alt: "Purple glass dropper bottle of L'Oréal Paris Revitalift 1.5% Pure Hyaluronic Acid Serum on travertine stone"
  },
  {
    id: "kiehls-ultra-facial-cream",
    brand: "Kiehl's",
    name: "Ultra Facial Cream",
    category: "Skincare",
    price: 39,
    size: "1.7 fl oz",
    summary: "24-hour barrier-strengthening moisturizer powered by squalane and glacial glycoprotein.",
    description:
      "Kiehl's #1 lightweight daily facial cream formulated to balance and replenish skin moisture across all skin types, including dry and sensitive skin.",
    keyBenefits: [
      "Supports skin moisture barrier with olive-derived squalane",
      "Fast-absorbing texture that leaves skin soft, not greasy",
      "Tested in extreme cold and dry climates"
    ],
    howToUse:
      "Smooth a dime-sized amount over face and neck after serums, morning and night.",
    image: "src/assets/images/kiehls_facial_cream_1795372671433.jpg",
    alt: "Matte white apothecary jar of Kiehl's Ultra Facial Cream with dark charcoal lid on stone pedestal"
  },
  {
    id: "laroche-anthelios-spf60",
    brand: "La Roche-Posay",
    name: "Anthelios Melt-in Milk Sunscreen SPF 60",
    category: "Skincare",
    price: 36,
    size: "5.0 fl oz",
    summary: "Broad-spectrum antioxidant sunscreen with a velvety, fast-absorbing finish.",
    description:
      "Dermatologist-recommended sun protection featuring Cell-Ox Shield technology to guard face and body against UVA/UVB rays without chalky cast.",
    keyBenefits: [
      "Broad-spectrum SPF 60 UVA and UVB defense",
      "Water-resistant up to 80 minutes",
      "Non-comedogenic and suitable for sensitive skin"
    ],
    howToUse:
      "Apply generously as the final skincare step 15 minutes before sun exposure, and reapply every 2 hours.",
    image: "src/assets/images/laroche_sunscreen_spf_1795372671907.jpg",
    alt: "Matte white tube of La Roche-Posay Anthelios Melt-in Milk Sunscreen SPF 60 on light travertine"
  },
  {
    id: "loreal-true-match-foundation",
    brand: "L'Oréal Paris",
    name: "True Match Super-Blendable Foundation",
    category: "Makeup",
    price: 16,
    size: "1.0 fl oz",
    summary: "Buildable medium coverage liquid foundation infused with hyaluronic acid.",
    description:
      "Breathable, skin-matching liquid foundation enriched with hyaluronic acid, vitamin E, and pro-vitamin B5 for a natural satin finish across undertones.",
    keyBenefits: [
      "True-to-skin pigments calibrated by warm, cool, and neutral undertones",
      "Hydrating formula that avoids caking in dry areas",
      "Lightweight medium coverage that wears comfortably all day"
    ],
    howToUse:
      "Blend evenly from the center of the face outward using fingers, sponge, or brush after moisturizer and SPF.",
    image: "src/assets/images/loreal_truematch_foundation_1795372671655.jpg",
    alt: "Frosted glass pump bottle of L'Oréal Paris True Match Super-Blendable Foundation on travertine"
  },
  {
    id: "maybelline-sky-high-mascara",
    brand: "Maybelline",
    name: "Lash Sensational Sky High Mascara",
    category: "Makeup",
    price: 13,
    size: "0.24 fl oz",
    summary: "Limitless length and root-to-tip volume with bamboo extract and fibers.",
    description:
      "Features the flexible Flex Tower brush that bends to reach every lash from root to tip, delivering smudge-resistant lift that removes easily with warm water.",
    keyBenefits: [
      "Bamboo extract and fiber-infused washable formula",
      "Flexible brush captures inner and outer corner lashes",
      "Ophthalmologist tested for sensitive eyes and contact wearers"
    ],
    howToUse:
      "Hold the flexible brush against lashes and sweep upward from root to tip, layering a second coat before it sets.",
    image: "src/assets/images/maybelline_skyhigh_mascara_1795372671424.jpg",
    alt: "Metallic blush-pink tube and precision wand of Maybelline Lash Sensational Sky High Mascara"
  },
  {
    id: "redken-acidic-bonding-leavein",
    brand: "Redken",
    name: "Acidic Bonding Concentrate Leave-In Treatment",
    category: "Haircare",
    price: 34,
    size: "5.1 fl oz",
    summary: "Intensive bond-repairing leave-in lotion with 450°F heat protection.",
    description:
      "Concentrated salon leave-in treatment formulated with citric acid and Redken's Bonding Care Complex to reinforce weakened hair bonds and tame frizz.",
    keyBenefits: [
      "Reduces visible split ends and breakage from styling",
      "Protects hair against heat tools up to 450°F",
      "Balances hair pH for smoother, shinier strands"
    ],
    howToUse:
      "Work a small amount through clean, damp hair from mid-lengths to ends before blow-drying or air-drying.",
    image: "src/assets/images/redken_bonding_treatment_1795372672216.jpg",
    alt: "Matte alabaster pump bottle of Redken Acidic Bonding Concentrate Leave-In Treatment on sandstone"
  },
  {
    id: "loreal-elvive-hyaluron-shampoo",
    brand: "L'Oréal Paris",
    name: "Elvive Hyaluron Plump Hydrating Shampoo",
    category: "Haircare",
    price: 8,
    size: "12.6 fl oz",
    summary: "Paraben-free moisturizing shampoo delivering 72-hour bounce and hydration.",
    description:
      "Inspired by skincare hydration, this gentle cleansing shampoo coats dry strands with hyaluronic acid care complex to leave hair bouncy without weighing it down.",
    keyBenefits: [
      "Replenishes moisture in dehydrated, dull hair",
      "Weightless cleanse suitable for fine to thick textures",
      "Leaves hair softer, shinier, and easier to detangle"
    ],
    howToUse:
      "Massage into wet scalp and hair, lather gently, and rinse thoroughly before conditioning or leave-in care.",
    image: "src/assets/images/elvive_hyaluron_shampoo_1795372671309.jpg",
    alt: "Glossy pastel lilac bottle of L'Oréal Paris Elvive Hyaluron Plump Hydrating Shampoo"
  },
  {
    id: "armani-my-way-edp",
    brand: "Armani Beauty",
    name: "My Way Eau de Parfum",
    category: "Fragrance",
    price: 135,
    size: "1.7 fl oz",
    summary: "Luminous white floral fragrance blending orange blossom, tuberose, and vanilla.",
    description:
      "An uplifting, refillable Eau de Parfum pairing bright Calabrian bergamot and Egyptian orange blossom with Indian tuberose, jasmine, and warm Madagascar vanilla.",
    keyBenefits: [
      "Bright floral heart balanced by warm cedarwood and vanilla",
      "Long-lasting Eau de Parfum concentration",
      "Refillable glass flacon crafted for everyday signature wear"
    ],
    howToUse:
      "Mist onto pulse points—wrists, neck, and behind ears—without rubbing so top and heart notes unfold naturally.",
    image: "src/assets/images/armani_myway_fragrance_1795372672218.jpg",
    alt: "Clear glass flacon with blush perfume and navy stone cap of Armani Beauty My Way Eau de Parfum"
  }
];
