// Send chat requests to the deployed Cloudflare Worker (holds OpenAI secret safely).
const workerUrl = "https://loreal-chatbot.leahbajnok.workers.dev/";

// Base system prompt guiding the advisor on L'Oréal Group products, routine building, and follow-ups.
const baseSystemPrompt =
  "You are a knowledgeable L'Oréal beauty advisor for the full L'Oréal Group portfolio, including L'Oréal Paris, Kiehl's, La Roche-Posay, Maybelline, NYX Professional Makeup, Lancôme, Redken, Pureology, CeraVe, Garnier, and Armani Beauty. When generating a personalized routine from a user's selected products, organize it into clear, numbered steps in the exact order they should be applied, explain briefly why each selected product fits that step, and keep the response focused and concise (under 220 words) so it reads cleanly. When answering follow-up questions, use the user's selected products and previously generated routine as context. If a product detail, shade, or price is uncertain, say so clearly and suggest checking the official brand packaging. Focus only on L'Oréal Group beauty topics, skincare, makeup, haircare, fragrance, routines, and beauty education.";

// UI translations and RTL/LTR direction metadata.
const I18N_UI = {
  en: {
    dir: "ltr",
    lang: "en",
    aiInstruction: "Respond in clear, natural English.",
    brandWordmark: "Smart Product Advisor",
    navCatalog: "Catalog",
    navSelected: "Selected Products",
    navAdvisor: "Beauty Advisor",
    navBrands: "Brands",
    viewRoutine: "View Routine",
    introKicker: "L'Oréal Group Portfolio · Personalized Routine Studio",
    introHeadline: "Curate your products. Generate your tailored beauty routine.",
    introLead:
      "Browse authentic L'Oréal Group skincare, makeup, haircare, and fragrance formulas, select the items you want to use together, and chat with your AI advisor to refine every step.",
    languageLabel: "Language & Layout",
    catalogHeading: "Product Catalog",
    showingCount: (shown, total) => `Showing ${shown} of ${total} products`,
    catAll: "All",
    catSkincare: "Skincare",
    catMakeup: "Makeup",
    catHaircare: "Haircare",
    catFragrance: "Fragrance",
    searchPlaceholder: "Search by product name, brand, or keyword…",
    allBrands: "All Brands",
    emptyCatalogTitle: "No matching products found",
    emptyCatalogCopy:
      "Try clearing your search term or switching back to all categories and brands.",
    resetFilters: "Reset Filters",
    selectBtn: "Select",
    selectedBtn: "Selected",
    detailsBtn: "Details",
    selectedProductsHeading: "Selected Products",
    selectedCount: (n) => (n === 1 ? "1 product selected" : `${n} products selected`),
    clearAll: "Clear All",
    selectedEmpty: "Select products from the catalog to build your custom routine.",
    routineFocus: "Routine Focus",
    timingFull: "Full Day",
    timingMorning: "Morning AM",
    timingEvening: "Evening PM",
    profileNotesLabel: "Skin, Hair, or Goal Notes (Optional)",
    profileNotesPlaceholder: "e.g., dry skin, frizz control, natural finish",
    generateRoutine: "Generate Routine",
    hintEmpty: "Choose at least 1 product above to unlock AI routine generation.",
    hintReady: "Ready to generate a step-by-step routine from your selected products.",
    advisorHeading: "Beauty Advisor",
    advisorSubtitle: "Ask follow-up questions about your routine",
    newChat: "New Chat",
    suggestedFollowUps: "Suggested follow-ups:",
    followUpOrder: "Application order",
    followUpOrderPrompt: "What exact order should I apply my selected products in?",
    followUpFrequency: "Daily frequency",
    followUpFrequencyPrompt:
      "Can I use these products together every day, or should any be spaced out?",
    followUpDryness: "Dryness adjustments",
    followUpDrynessPrompt:
      "How can I adapt this routine if my skin or hair feels extra dry?",
    chatPlaceholderDefault: "Ask a follow-up about your routine or products…",
    chatPlaceholderActive: "Ask a follow-up question about your routine…",
    greeting:
      "Hello! Select L'Oréal products from the catalog and click Generate Routine, or ask me any beauty question here.",
    thinking: "Thinking through your routine…",
    retrying: "Advisor is busy right now. Retrying in a moment…",
    brandsHeading: "Explore by L'Oréal Group Brand",
    brandsSubtitle: "Select a maison or clinical label to filter the catalog",
    keyBenefits: "Key Benefits",
    howToUse: "How to Use",
    addToRoutine: "Add to Routine",
    removeFromRoutine: "Remove from Routine",
    footerCopy: "L'Oréal Smart Product Advisor · Curated L'Oréal Group Portfolio"
  },
  ar: {
    dir: "rtl",
    lang: "ar",
    aiInstruction:
      "Respond in clear, natural Arabic (العربية), keeping official L'Oréal product names recognizable.",
    brandWordmark: "مستشار المنتجات الذكي",
    navCatalog: "المنتجات",
    navSelected: "المنتجات المختارة",
    navAdvisor: "مستشار الجمال",
    navBrands: "العلامات التجارية",
    viewRoutine: "عرض الروتين",
    introKicker: "مجموعة لوريال · استوديو الروتين الشخصي",
    introHeadline: "اختاري منتجاتكِ. وأنشئي روتين جمالكِ المخصص بالذكاء الاصطناعي.",
    introLead:
      "تصفحي مستحضرات العناية بالبشرة والمكياج والشعر والعطور من مجموعة لوريال، وحددي ما يناسبكِ، ثم تحدثي مع مستشار الجمال لتخصيص كل خطوة.",
    languageLabel: "اللغة واتجاه التصميم",
    catalogHeading: "دليل المنتجات",
    showingCount: (shown, total) => `عرض ${shown} من أصل ${total} منتجات`,
    catAll: "الكل",
    catSkincare: "العناية بالبشرة",
    catMakeup: "المكياج",
    catHaircare: "العناية بالشعر",
    catFragrance: "العطور",
    searchPlaceholder: "ابحثي باسم المنتج أو العلامة التجارية أو المكونات…",
    allBrands: "كل العلامات التجارية",
    emptyCatalogTitle: "لم يتم العثور على منتجات مطابقة",
    emptyCatalogCopy:
      "جرّبي مسح كلمة البحث أو العودة إلى جميع الفئات والعلامات التجارية.",
    resetFilters: "إعادة ضبط الفلاتر",
    selectBtn: "اختيار",
    selectedBtn: "مختار",
    detailsBtn: "التفاصيل",
    selectedProductsHeading: "المنتجات المختارة",
    selectedCount: (n) => (n === 1 ? "منتج واحد مختار" : `${n} منتجات مختارة`),
    clearAll: "مسح الكل",
    selectedEmpty: "اختاري المنتجات من الدليل لبناء روتينكِ المخصص.",
    routineFocus: "توقيت الروتين",
    timingFull: "يوم كامل",
    timingMorning: "الصباح",
    timingEvening: "المساء",
    profileNotesLabel: "ملاحظات البشرة أو الشعر أو الأهداف (اختياري)",
    profileNotesPlaceholder: "مثال: بشرة جافة، التحكم في الهيشان، مظهر طبيعي",
    generateRoutine: "إنشاء الروتين",
    hintEmpty: "اختاري منتجاً واحداً على الأقل لتفعيل إنشاء الروتين بالذكاء الاصطناعي.",
    hintReady: "جاهز لإنشاء روتين متدرج باستخدام المنتجات التي اخترتها.",
    advisorHeading: "مستشار الجمال",
    advisorSubtitle: "اطرحي أسئلة متابعة حول روتينكِ",
    newChat: "محادثة جديدة",
    suggestedFollowUps: "أسئلة مقترحة للمتابعة:",
    followUpOrder: "ترتيب الاستخدام",
    followUpOrderPrompt: "ما هو الترتيب الدقيق لاستخدام المنتجات التي اخترتها؟",
    followUpFrequency: "التكرار اليومي",
    followUpFrequencyPrompt:
      "هل يمكنني استخدام هذه المنتجات معاً يومياً، أم يفضل المباعدة بينها؟",
    followUpDryness: "تعديلات للجفاف",
    followUpDrynessPrompt:
      "كيف يمكنني تكييف هذا الروتين إذا شعرت بجفاف إضافي في البشرة أو الشعر؟",
    chatPlaceholderDefault: "اسألي عن روتينكِ أو المنتجات المختارة…",
    chatPlaceholderActive: "اطرحي سؤال متابعة حول روتينكِ…",
    greeting:
      "مرحباً! اختاري منتجات لوريال من الدليل واضغطي على إنشاء الروتين، أو اسأليني أي سؤال عن الجمال هنا.",
    thinking: "جاري إعداد روتينكِ المخصص…",
    retrying: "المستشار مشغول حالياً. جاري إعادة المحاولة…",
    brandsHeading: "استكشفي حسب علامات مجموعة لوريال",
    brandsSubtitle: "اختاري علامة تجارية لتصفية دليل المنتجات",
    keyBenefits: "أهم الفوائد",
    howToUse: "طريقة الاستخدام",
    addToRoutine: "إضافة إلى الروتين",
    removeFromRoutine: "إزالة من الروتين",
    footerCopy: "مستشار منتجات لوريال الذكي · مجموعة لوريال المختارة"
  },
  he: {
    dir: "rtl",
    lang: "he",
    aiInstruction:
      "Respond in clear, natural Hebrew (עברית), keeping official L'Oréal product names recognizable.",
    brandWordmark: "יועץ המוצרים החכם",
    navCatalog: "קטלוג",
    navSelected: "מוצרים נבחרים",
    navAdvisor: "יועץ היופי",
    navBrands: "מותגים",
    viewRoutine: "צפייה בשגרה",
    introKicker: "פורטפוליו לוריאל · סטודיו לשגרה מותאמת אישית",
    introHeadline: "בחרו את המוצרים. צרו שגרת טיפוח מותאמת אישית.",
    introLead:
      "עיינו במוצרי טיפוח, איפור, שיער ובישום של קבוצת לוריאל, בחרו את המוצרים הרצויים ושוחחו עם יועץ ה-AI לדיוק כל שלב.",
    languageLabel: "שפה וכיוון פריסה",
    catalogHeading: "קטלוג מוצרים",
    showingCount: (shown, total) => `מציג ${shown} מתוך ${total} מוצרים`,
    catAll: "הכול",
    catSkincare: "טיפוח עור",
    catMakeup: "איפור",
    catHaircare: "טיפוח שיער",
    catFragrance: "בישום",
    searchPlaceholder: "חיפוש לפי שם מוצר, מותג או מילת מפתח…",
    allBrands: "כל המותגים",
    emptyCatalogTitle: "לא נמצאו מוצרים תואמים",
    emptyCatalogCopy: "נסו לנקות את מילת החיפוש או לחזור לכל הקטגוריות והמותגים.",
    resetFilters: "איפוס סינון",
    selectBtn: "בחירה",
    selectedBtn: "נבחר",
    detailsBtn: "פרטים",
    selectedProductsHeading: "מוצרים נבחרים",
    selectedCount: (n) => (n === 1 ? "מוצר אחד נבחר" : `${n} מוצרים נבחרו`),
    clearAll: "נקה הכול",
    selectedEmpty: "בחרו מוצרים מהקטלוג כדי לבנות את השגרה המותאמת שלכם.",
    routineFocus: "מיקוד השגרה",
    timingFull: "יום מלא",
    timingMorning: "בוקר",
    timingEvening: "ערב",
    profileNotesLabel: "הערות על העור, השיער או המטרה (אופציונלי)",
    profileNotesPlaceholder: "לדוגמה: עור יבש, שליטה בקרזול, גימור טבעי",
    generateRoutine: "יצירת שגרה",
    hintEmpty: "בחרו לפחות מוצר אחד למעלה כדי ליצור שגרה מותאמת.",
    hintReady: "מוכן ליצירת שגרה שלב-אחר-שלב מהמוצרים שנבחרו.",
    advisorHeading: "יועץ היופי",
    advisorSubtitle: "שאלו שאלות המשך על השגרה שלכם",
    newChat: "שיחה חדשה",
    suggestedFollowUps: "שאלות המשך מוצעות:",
    followUpOrder: "סדר המריחה",
    followUpOrderPrompt: "מהו הסדר המדויק שבו כדאי להשתמש במוצרים שבחרתי?",
    followUpFrequency: "תדירות יומית",
    followUpFrequencyPrompt:
      "האם ניתן להשתמש במוצרים האלה יחד בכל יום, או שכדאי לרווח ביניהם?",
    followUpDryness: "התאמה ליובש",
    followUpDrynessPrompt:
      "איך ניתן להתאים את השגרה הזו אם העור או השיער מרגישים יבשים במיוחד?",
    chatPlaceholderDefault: "שאלו שאלה על השגרה או המוצרים…",
    chatPlaceholderActive: "שאלו שאלת המשך על השגרה שלכם…",
    greeting:
      "שלום! בחרו מוצרי לוריאל מהקטלוג ולחצו על יצירת שגרה, או שאלו אותי כל שאלת יופי כאן.",
    thinking: "בונה עבורכם שגרה מותאמת…",
    retrying: "היועץ עמוס כרגע. מנסה שוב בעוד רגע…",
    brandsHeading: "גלו לפי מותג בקבוצת לוריאל",
    brandsSubtitle: "בחרו מותג כדי לסנן את הקטלוג",
    keyBenefits: "יתרונות עיקריים",
    howToUse: "אופן השימוש",
    addToRoutine: "הוספה לשגרה",
    removeFromRoutine: "הסרה מהשגרה",
    footerCopy: "יועץ המוצרים החכם של לוריאל · פורטפוליו נבחר"
  }
};

// DOM element references.
const languageSelect = document.getElementById("languageSelect");
const productGrid = document.getElementById("productGrid");
const emptyCatalogState = document.getElementById("emptyCatalogState");
const catalogCountText = document.getElementById("catalogCountText");
const searchInput = document.getElementById("searchInput");
const clearSearchBtn = document.getElementById("clearSearchBtn");
const brandSelect = document.getElementById("brandSelect");
const categoryTabs = document.querySelectorAll(".category-tab");
const resetFiltersBtn = document.getElementById("resetFiltersBtn");

const headerSelectedCount = document.getElementById("headerSelectedCount");
const jumpToRoutineBtn = document.getElementById("jumpToRoutineBtn");
const selectedSummaryText = document.getElementById("selectedSummaryText");
const selectedList = document.getElementById("selectedList");
const clearSelectionBtn = document.getElementById("clearSelectionBtn");
const timingButtons = document.querySelectorAll(".timing-btn");
const profileNotesInput = document.getElementById("profileNotesInput");
const generateRoutineBtn = document.getElementById("generateRoutineBtn");
const generateHint = document.getElementById("generateHint");

const chatWindow = document.getElementById("chatWindow");
const chatForm = document.getElementById("chatForm");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const resetChatBtn = document.getElementById("resetChatBtn");
const followUpBar = document.getElementById("followUpBar");
const followUpButtons = document.querySelectorAll(".followup-btn");
const brandJumpButtons = document.querySelectorAll("[data-brand-jump]");

// Product modal elements.
const productModal = document.getElementById("productModal");
const closeModalBtn = document.getElementById("closeModalBtn");
const modalImage = document.getElementById("modalImage");
const modalMeta = document.getElementById("modalMeta");
const modalTitle = document.getElementById("modalTitle");
const modalPrice = document.getElementById("modalPrice");
const modalDescription = document.getElementById("modalDescription");
const modalBenefits = document.getElementById("modalBenefits");
const modalHowToUse = document.getElementById("modalHowToUse");
const modalToggleSelectBtn = document.getElementById("modalToggleSelectBtn");

// Application state.
let currentLanguage = loadSavedLanguage();
let activeCategory = "All";
let activeBrand = "All";
let searchQuery = "";
let selectedTiming = "Full Day (AM & PM)";
let selectedProductIds = loadSavedSelections();
let activeModalProductId = null;
let isRequestInFlight = false;
let messages = [{ role: "system", content: getSystemPrompt() }];
let chatDisplayLog = [];
let lastSentSelectionSignature = "";

// Return active UI dictionary for the current language.
function t() {
  return I18N_UI[currentLanguage] || I18N_UI.en;
}

// Build the system prompt with the active language instruction.
function getSystemPrompt() {
  return `${baseSystemPrompt} ${t().aiInstruction}`;
}

// Load saved language preference safely.
function loadSavedLanguage() {
  try {
    const saved = window.localStorage.getItem("loreal_language");
    if (saved && I18N_UI[saved]) {
      return saved;
    }
  } catch {
    // Ignore storage errors.
  }
  return "en";
}

// Apply language, HTML dir ("ltr" or "rtl"), and update all static UI strings.
function applyLanguage(langCode, persist = true) {
  currentLanguage = I18N_UI[langCode] ? langCode : "en";
  const strings = t();

  document.documentElement.dir = strings.dir;
  document.documentElement.lang = strings.lang;
  languageSelect.value = currentLanguage;

  if (persist) {
    try {
      window.localStorage.setItem("loreal_language", currentLanguage);
    } catch {
      // Ignore storage errors.
    }
  }

  // Keep system prompt aligned with active language.
  if (messages.length > 0 && messages[0].role === "system") {
    messages[0].content = getSystemPrompt();
  }

  // Update all [data-i18n] elements.
  for (const el of document.querySelectorAll("[data-i18n]")) {
    const key = el.dataset.i18n;
    if (key && typeof strings[key] === "string") {
      el.textContent = strings[key];
    }
  }

  // Update dynamic placeholders and follow-up buttons.
  searchInput.placeholder = strings.searchPlaceholder;
  profileNotesInput.placeholder = strings.profileNotesPlaceholder;
  userInput.placeholder =
    chatDisplayLog.length > 0
      ? strings.chatPlaceholderActive
      : strings.chatPlaceholderDefault;

  for (const btn of followUpButtons) {
    const fKey = btn.dataset.followupKey;
    if (fKey === "order") {
      btn.textContent = strings.followUpOrder;
      btn.dataset.prompt = strings.followUpOrderPrompt;
    } else if (fKey === "frequency") {
      btn.textContent = strings.followUpFrequency;
      btn.dataset.prompt = strings.followUpFrequencyPrompt;
    } else if (fKey === "dryness") {
      btn.textContent = strings.followUpDryness;
      btn.dataset.prompt = strings.followUpDrynessPrompt;
    }
  }

  renderCatalog();
  renderSelectedRoutine();
  updateModalToggleButton();
}

// Load any saved product selections from localStorage safely.
function loadSavedSelections() {
  try {
    const raw = window.localStorage.getItem("loreal_selected_products");
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }
    const validIds = new Set(LOREAL_PRODUCTS.map((item) => item.id));
    return [...new Set(parsed.filter((id) => validIds.has(id)))];
  } catch {
    return [];
  }
}

// Persist selected product IDs to localStorage (or clear key when empty).
function saveSelections() {
  try {
    if (selectedProductIds.length === 0) {
      window.localStorage.removeItem("loreal_selected_products");
      return;
    }
    window.localStorage.setItem(
      "loreal_selected_products",
      JSON.stringify(selectedProductIds)
    );
  } catch {
    // Ignore storage quota or private browsing errors.
  }
}

// Persist both the OpenAI conversation history and visible chat bubbles.
function saveChatHistory() {
  try {
    window.localStorage.setItem(
      "loreal_chat_history",
      JSON.stringify({
        messages: messages.slice(1),
        displayLog: chatDisplayLog,
        selectionSignature: lastSentSelectionSignature
      })
    );
  } catch {
    // Ignore storage quota or private browsing errors.
  }
}

// Load saved conversation history if present.
function loadChatHistory() {
  try {
    const raw = window.localStorage.getItem("loreal_chat_history");
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.messages) || !Array.isArray(parsed.displayLog)) {
      return null;
    }
    const validMessages = parsed.messages.filter(
      (msg) =>
        msg &&
        (msg.role === "user" || msg.role === "assistant") &&
        typeof msg.content === "string"
    );
    const validDisplay = parsed.displayLog.filter(
      (entry) =>
        entry &&
        (entry.roleClass === "user" || entry.roleClass === "ai") &&
        typeof entry.text === "string"
    );
    if (validMessages.length === 0 || validDisplay.length === 0) {
      return null;
    }
    return {
      messages: validMessages,
      displayLog: validDisplay,
      selectionSignature:
        typeof parsed.selectionSignature === "string" ? parsed.selectionSignature : ""
    };
  } catch {
    return null;
  }
}

// Find a product object by ID.
function getProductById(productId) {
  return LOREAL_PRODUCTS.find((product) => product.id === productId) || null;
}

// Return all currently selected product objects.
function getSelectedProducts() {
  return selectedProductIds
    .map((id) => getProductById(id))
    .filter((product) => product !== null);
}

// Normalize text (lowercase + strip accents) so "loreal" matches "L'Oréal".
function normalizeSearchText(value) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

// Filter the catalog using category, brand, and multi-word keyword search.
function getFilteredProducts() {
  const queryTerms = normalizeSearchText(searchQuery.trim())
    .split(/\s+/)
    .filter(Boolean);

  return LOREAL_PRODUCTS.filter((product) => {
    const matchesCategory =
      activeCategory === "All" || product.category === activeCategory;
    const matchesBrand =
      activeBrand === "All" || product.brand === activeBrand;

    if (!matchesCategory || !matchesBrand) {
      return false;
    }

    if (queryTerms.length === 0) {
      return true;
    }

    const searchableText = normalizeSearchText(
      [
        product.brand,
        product.name,
        product.category,
        product.summary,
        product.description,
        product.howToUse,
        ...product.keyBenefits
      ].join(" ")
    );

    return queryTerms.every((term) => searchableText.includes(term));
  });
}

// Toggle a product in or out of the user's selected routine list.
function toggleProductSelection(productId) {
  if (selectedProductIds.includes(productId)) {
    selectedProductIds = selectedProductIds.filter((id) => id !== productId);
  } else {
    selectedProductIds = [...selectedProductIds, productId];
  }

  saveSelections();
  renderCatalog();
  renderSelectedRoutine();
  updateModalToggleButton();
}

// Render the filtered catalog grid using safe DOM creation.
function renderCatalog() {
  const strings = t();
  const filteredProducts = getFilteredProducts();
  catalogCountText.textContent = strings.showingCount(
    filteredProducts.length,
    LOREAL_PRODUCTS.length
  );

  productGrid.replaceChildren();

  if (filteredProducts.length === 0) {
    emptyCatalogState.hidden = false;
    return;
  }

  emptyCatalogState.hidden = true;

  for (const product of filteredProducts) {
    const isSelected = selectedProductIds.includes(product.id);

    const card = document.createElement("article");
    card.className = isSelected ? "product-card is-selected" : "product-card";
    card.setAttribute("aria-labelledby", `product-title-${product.id}`);
    card.setAttribute("aria-describedby", `product-desc-${product.id}`);

    // Clicking anywhere on the card toggles selection (inner buttons stop propagation).
    card.addEventListener("click", () => toggleProductSelection(product.id));

    // Image area with optional Selected visual marker.
    const media = document.createElement("div");
    media.className = "product-media";

    const img = document.createElement("img");
    img.src = product.image;
    img.alt = product.alt;
    img.loading = "lazy";
    img.referrerPolicy = "no-referrer";
    img.addEventListener("error", () => {
      media.classList.add("has-error");
    });

    const fallback = document.createElement("div");
    fallback.className = "image-fallback";
    fallback.setAttribute("aria-hidden", "true");
    const fallbackIcon = document.createElement("span");
    fallbackIcon.className = "material-icons";
    fallbackIcon.textContent = "spa";
    const fallbackLabel = document.createElement("span");
    fallbackLabel.textContent = product.brand;
    fallback.append(fallbackIcon, fallbackLabel);

    media.append(img, fallback);

    if (isSelected) {
      const selectedTag = document.createElement("div");
      selectedTag.className = "product-selected-indicator";
      const checkIcon = document.createElement("span");
      checkIcon.className = "material-icons";
      checkIcon.setAttribute("aria-hidden", "true");
      checkIcon.textContent = "check_circle";
      const tagText = document.createElement("span");
      tagText.textContent = strings.selectedBtn;
      selectedTag.append(checkIcon, tagText);
      media.appendChild(selectedTag);
    }

    // Card content body.
    const body = document.createElement("div");
    body.className = "product-body";

    const metaRow = document.createElement("div");
    metaRow.className = "product-meta-row";

    const brandCat = document.createElement("span");
    brandCat.className = "product-brand-cat";
    brandCat.textContent = `${product.brand} · ${product.category}`;

    const price = document.createElement("span");
    price.className = "product-price tabular-nums";
    price.textContent = `$${product.price}`;

    metaRow.append(brandCat, price);

    const title = document.createElement("h3");
    title.id = `product-title-${product.id}`;
    title.className = "product-title";
    title.textContent = product.name;

    const description = document.createElement("p");
    description.id = `product-desc-${product.id}`;
    description.className = "product-summary";
    description.textContent = product.description;

    const actions = document.createElement("div");
    actions.className = "product-actions";

    const selectBtn = document.createElement("button");
    selectBtn.type = "button";
    selectBtn.className = isSelected
      ? "select-product-btn is-selected"
      : "select-product-btn";
    selectBtn.setAttribute("aria-pressed", String(isSelected));
    selectBtn.setAttribute(
      "aria-label",
      isSelected
        ? `Unselect ${product.brand} ${product.name}`
        : `Select ${product.brand} ${product.name}`
    );

    const selectIcon = document.createElement("span");
    selectIcon.className = "material-icons";
    selectIcon.setAttribute("aria-hidden", "true");
    selectIcon.textContent = isSelected ? "check" : "add";

    const selectLabel = document.createElement("span");
    selectLabel.textContent = isSelected ? strings.selectedBtn : strings.selectBtn;

    selectBtn.append(selectIcon, selectLabel);
    selectBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleProductSelection(product.id);
    });

    const detailsBtn = document.createElement("button");
    detailsBtn.type = "button";
    detailsBtn.className = "details-btn";
    detailsBtn.textContent = strings.detailsBtn;
    detailsBtn.setAttribute("aria-haspopup", "dialog");
    detailsBtn.setAttribute(
      "aria-label",
      `View key benefits and usage for ${product.brand} ${product.name}`
    );
    detailsBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      openProductModal(product.id);
    });

    actions.append(selectBtn, detailsBtn);
    body.append(metaRow, title, description, actions);
    card.append(media, body);
    productGrid.appendChild(card);
  }
}

// Render the selected products list and update counts/CTA states.
function renderSelectedRoutine() {
  const strings = t();
  const selectedProducts = getSelectedProducts();
  const count = selectedProducts.length;

  headerSelectedCount.textContent = String(count);
  selectedSummaryText.textContent = strings.selectedCount(count);

  clearSelectionBtn.disabled = count === 0;
  generateRoutineBtn.disabled = count === 0 || isRequestInFlight;

  generateHint.textContent = count === 0 ? strings.hintEmpty : strings.hintReady;

  selectedList.replaceChildren();

  if (count === 0) {
    const emptyMessage = document.createElement("p");
    emptyMessage.className = "selected-empty";
    emptyMessage.textContent = strings.selectedEmpty;
    selectedList.appendChild(emptyMessage);
    return;
  }

  for (const product of selectedProducts) {
    const row = document.createElement("div");
    row.className = "selected-item";

    const textWrap = document.createElement("div");
    textWrap.className = "selected-item-text";

    const brandSpan = document.createElement("span");
    brandSpan.className = "selected-item-brand";
    brandSpan.textContent = `${product.brand} · ${product.category}`;

    const nameSpan = document.createElement("span");
    nameSpan.className = "selected-item-name";
    nameSpan.textContent = product.name;

    textWrap.append(brandSpan, nameSpan);

    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "remove-item-btn";
    removeBtn.title = `Remove ${product.name}`;
    removeBtn.setAttribute("aria-label", `Remove ${product.name} from selected products`);
    removeBtn.addEventListener("click", () => toggleProductSelection(product.id));

    const closeIcon = document.createElement("span");
    closeIcon.className = "material-icons";
    closeIcon.setAttribute("aria-hidden", "true");
    closeIcon.textContent = "close";

    removeBtn.appendChild(closeIcon);
    row.append(textWrap, removeBtn);
    selectedList.appendChild(row);
  }
}

// Open the product detail modal for a given product ID.
function openProductModal(productId) {
  const product = getProductById(productId);
  if (!product) {
    return;
  }

  activeModalProductId = product.id;

  const modalMedia = modalImage.parentElement;
  modalMedia.classList.remove("has-error");
  modalImage.src = product.image;
  modalImage.alt = product.alt;

  modalMeta.textContent = `${product.brand} · ${product.category}`;
  modalTitle.textContent = product.name;
  modalPrice.textContent = `$${product.price} · ${product.size}`;
  modalDescription.textContent = product.description;
  modalHowToUse.textContent = product.howToUse;

  modalBenefits.replaceChildren();
  for (const benefit of product.keyBenefits) {
    const li = document.createElement("li");
    li.textContent = benefit;
    modalBenefits.appendChild(li);
  }

  updateModalToggleButton();
  productModal.hidden = false;
  closeModalBtn.focus();
}

// Close the product detail modal.
function closeProductModal() {
  productModal.hidden = true;
  activeModalProductId = null;
}

// Keep the modal's select/remove button label synchronized.
function updateModalToggleButton() {
  if (!activeModalProductId) {
    return;
  }
  const strings = t();
  const isSelected = selectedProductIds.includes(activeModalProductId);
  modalToggleSelectBtn.textContent = isSelected
    ? strings.removeFromRoutine
    : strings.addToRoutine;
}

// Append inline text with bold (**text**) segments safely without innerHTML.
function appendFormattedInline(parent, text) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  for (const part of parts) {
    if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
      const strong = document.createElement("strong");
      strong.textContent = part.slice(2, -2);
      parent.appendChild(strong);
    } else if (part) {
      parent.appendChild(document.createTextNode(part));
    }
  }
}

// Format AI replies (headings, lists, paragraphs) safely into clean DOM nodes.
function renderFormattedMessageContent(container, text) {
  const lines = text.split("\n");
  let activeList = null;

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (!line) {
      activeList = null;
      continue;
    }

    // Match markdown-style headings like ### Morning Routine.
    if (/^#{1,3}\s+/.test(line)) {
      activeList = null;
      const heading = document.createElement("h4");
      heading.className = "msg-heading";
      heading.textContent = line.replace(/^#{1,3}\s+/, "").replace(/\*\*/g, "");
      container.appendChild(heading);
      continue;
    }

    // Match bullet or numbered list lines.
    const bulletMatch = line.match(/^([-*]|\d+[.)])\s+(.*)$/);
    if (bulletMatch) {
      if (!activeList) {
        activeList = document.createElement("ul");
        activeList.className = "msg-list";
        container.appendChild(activeList);
      }
      const li = document.createElement("li");
      appendFormattedInline(li, bulletMatch[2]);
      activeList.appendChild(li);
      continue;
    }

    activeList = null;
    const paragraph = document.createElement("p");
    paragraph.className = "msg-paragraph";
    appendFormattedInline(paragraph, line);
    container.appendChild(paragraph);
  }
}

// Add a chat message bubble to the advisor window.
function addMessage(roleClass, text, isLoading = false) {
  const message = document.createElement("div");
  message.className = isLoading ? `msg ${roleClass} msg-loading` : `msg ${roleClass}`;
  message.dir = "auto";

  if (roleClass === "ai" && !isLoading) {
    renderFormattedMessageContent(message, text);
  } else {
    message.textContent = text;
  }

  chatWindow.appendChild(message);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return message;
}

// Helper pause for rate-limit retries.
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Toggle busy state across chat and routine generation controls.
function setBusyState(busy) {
  isRequestInFlight = busy;
  userInput.disabled = busy;
  sendBtn.disabled = busy;
  generateRoutineBtn.disabled = busy || selectedProductIds.length === 0;
}

// Send the current conversation history to the Cloudflare Worker and display the reply.
async function requestAdvisorReply(userPromptText, displayText) {
  if (isRequestInFlight) {
    return false;
  }

  const strings = t();
  addMessage("user", displayText || userPromptText);
  messages.push({ role: "user", content: userPromptText });

  setBusyState(true);
  const loadingBubble = addMessage("ai", strings.thinking, true);
  let retryCount = 0;

  try {
    while (true) {
      const response = await fetch(workerUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages })
      });

      if (response.status === 429) {
        if (retryCount < 2) {
          retryCount += 1;
          loadingBubble.textContent = strings.retrying;
          await wait(2000 * retryCount);
          continue;
        }
        throw new Error(
          "The chat service is rate-limited right now. Please wait a minute and try again."
        );
      }

      if (!response.ok) {
        throw new Error(`The chat service returned status ${response.status}.`);
      }

      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        throw new Error("The chat service did not return a JSON response.");
      }

      const data = await response.json();
      const reply = data.choices?.[0]?.message?.content;

      if (typeof reply !== "string" || !reply.trim()) {
        throw new Error("The chat service returned an unexpected response.");
      }

      loadingBubble.remove();
      addMessage("ai", reply);
      messages.push({ role: "assistant", content: reply });
      chatDisplayLog.push(
        { roleClass: "user", text: displayText || userPromptText },
        { roleClass: "ai", text: reply }
      );
      lastSentSelectionSignature = selectedProductIds.join(",");
      saveChatHistory();
      followUpBar.hidden = false;
      userInput.placeholder = strings.chatPlaceholderActive;
      return true;
    }
  } catch (error) {
    console.error("Chat request failed:", error);
    loadingBubble.remove();
    addMessage("ai", `Sorry, I couldn't get a reply. ${error.message}`);
    messages.pop();
    return false;
  } finally {
    setBusyState(false);
    userInput.focus();
  }
}

// Collect only the selected products and send their JSON data to the OpenAI API via the Worker.
async function handleGenerateRoutine() {
  const selectedProducts = getSelectedProducts();
  if (selectedProducts.length === 0) {
    return;
  }

  const notes = profileNotesInput.value.trim();

  // Build a clean JSON array containing only the selected products' data.
  const selectedProductsJson = selectedProducts.map((product) => ({
    id: product.id,
    brand: product.brand,
    name: product.name,
    category: product.category,
    price: product.price,
    size: product.size,
    description: product.description,
    keyBenefits: product.keyBenefits,
    howToUse: product.howToUse
  }));

  const displayMessage = `Generate a ${selectedTiming} routine for my ${selectedProducts.length} selected product${selectedProducts.length === 1 ? "" : "s"}${notes ? ` (Notes: ${notes})` : ""}.`;

  const promptForAI = [
    `Generate a personalized ${selectedTiming} beauty routine using ONLY the selected L'Oréal Group products in this JSON data:`,
    JSON.stringify(selectedProductsJson, null, 2),
    notes ? `User profile or goals: ${notes}.` : "",
    `${t().aiInstruction} Organize the routine into numbered steps in exact application order with brief usage tips for each selected product, keeping the response concise and complete.`
  ]
    .filter(Boolean)
    .join("\n\n");

  document
    .getElementById("advisorPanel")
    .scrollIntoView({ behavior: "smooth", block: "nearest" });

  await requestAdvisorReply(promptForAI, displayMessage);
}

// Reset the conversation back to a fresh advisor greeting.
function resetAdvisorChat() {
  const strings = t();
  messages = [{ role: "system", content: getSystemPrompt() }];
  chatDisplayLog = [];
  lastSentSelectionSignature = "";
  try {
    window.localStorage.removeItem("loreal_chat_history");
  } catch {
    // Ignore storage errors.
  }
  chatWindow.replaceChildren();
  followUpBar.hidden = true;
  userInput.placeholder = strings.chatPlaceholderDefault;
  addMessage("ai", strings.greeting);
}

// Restore saved multi-turn conversation on page load if available.
function initializeAdvisorChat() {
  const strings = t();
  const saved = loadChatHistory();
  if (!saved) {
    resetAdvisorChat();
    return;
  }

  messages = [{ role: "system", content: getSystemPrompt() }, ...saved.messages];
  chatDisplayLog = saved.displayLog;
  lastSentSelectionSignature = saved.selectionSignature;

  chatWindow.replaceChildren();
  addMessage("ai", strings.greeting);
  for (const entry of chatDisplayLog) {
    addMessage(entry.roleClass, entry.text);
  }
  followUpBar.hidden = false;
  userInput.placeholder = strings.chatPlaceholderActive;
}

// Wire up catalog category tabs.
for (const tab of categoryTabs) {
  tab.addEventListener("click", () => {
    activeCategory = tab.dataset.category || "All";
    for (const item of categoryTabs) {
      const isCurrent = item === tab;
      item.classList.toggle("is-active", isCurrent);
      item.setAttribute("aria-selected", String(isCurrent));
    }
    renderCatalog();
  });
}

// Wire up brand dropdown and search input.
brandSelect.addEventListener("change", () => {
  activeBrand = brandSelect.value;
  renderCatalog();
});

searchInput.addEventListener("input", () => {
  searchQuery = searchInput.value;
  clearSearchBtn.hidden = searchQuery.length === 0;
  renderCatalog();
});

clearSearchBtn.addEventListener("click", () => {
  searchQuery = "";
  searchInput.value = "";
  clearSearchBtn.hidden = true;
  renderCatalog();
  searchInput.focus();
});

resetFiltersBtn.addEventListener("click", () => {
  activeCategory = "All";
  activeBrand = "All";
  searchQuery = "";
  brandSelect.value = "All";
  searchInput.value = "";
  clearSearchBtn.hidden = true;
  for (const item of categoryTabs) {
    const isAll = item.dataset.category === "All";
    item.classList.toggle("is-active", isAll);
    item.setAttribute("aria-selected", String(isAll));
  }
  renderCatalog();
});

// Wire up brand strip quick-filter cards.
for (const brandBtn of brandJumpButtons) {
  brandBtn.addEventListener("click", () => {
    const brandName = brandBtn.dataset.brandJump || "All";
    activeBrand = brandName;
    activeCategory = "All";
    brandSelect.value = brandName;
    for (const item of categoryTabs) {
      const isAll = item.dataset.category === "All";
      item.classList.toggle("is-active", isAll);
      item.setAttribute("aria-selected", String(isAll));
    }
    renderCatalog();
    document.getElementById("catalog").scrollIntoView({ behavior: "smooth" });
  });
}

// Wire up routine timing buttons and clear button.
for (const timingBtn of timingButtons) {
  timingBtn.addEventListener("click", () => {
    selectedTiming = timingBtn.dataset.timing || "Full Day (AM & PM)";
    for (const btn of timingButtons) {
      btn.classList.toggle("is-active", btn === timingBtn);
    }
  });
}

clearSelectionBtn.addEventListener("click", () => {
  selectedProductIds = [];
  saveSelections();
  renderCatalog();
  renderSelectedRoutine();
  updateModalToggleButton();
});

jumpToRoutineBtn.addEventListener("click", () => {
  document
    .getElementById("routineBuilder")
    .scrollIntoView({ behavior: "smooth", block: "start" });
});

generateRoutineBtn.addEventListener("click", handleGenerateRoutine);

// Wire up advisor chat form, follow-up quick prompts, and reset button.
chatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const userMessage = userInput.value.trim();
  if (!userMessage) {
    return;
  }
  userInput.value = "";

  // Keep selection context fresh if the user changed selected products before asking a follow-up.
  const selectedProducts = getSelectedProducts();
  const currentSignature = selectedProductIds.join(",");
  let promptToSend = userMessage;

  if (selectedProducts.length > 0 && currentSignature !== lastSentSelectionSignature) {
    const names = selectedProducts
      .map((p) => `${p.brand} ${p.name}`)
      .join(", ");
    promptToSend = `Current selected products: ${names}.\n\nUser question: ${userMessage}`;
  }

  await requestAdvisorReply(promptToSend, userMessage);
});

for (const btn of followUpButtons) {
  btn.addEventListener("click", async () => {
    const followUpPrompt = btn.dataset.prompt;
    if (!followUpPrompt) {
      return;
    }
    await requestAdvisorReply(followUpPrompt, followUpPrompt);
  });
}

resetChatBtn.addEventListener("click", resetAdvisorChat);

// Wire up product detail modal interactions.
modalImage.addEventListener("error", () => {
  modalImage.parentElement.classList.add("has-error");
});

closeModalBtn.addEventListener("click", closeProductModal);

productModal.addEventListener("click", (event) => {
  if (event.target === productModal) {
    closeProductModal();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !productModal.hidden) {
    closeProductModal();
  }
});

modalToggleSelectBtn.addEventListener("click", () => {
  if (activeModalProductId) {
    toggleProductSelection(activeModalProductId);
  }
});

// Wire up language & RTL/LTR layout selector.
languageSelect.addEventListener("change", () => {
  applyLanguage(languageSelect.value, true);
  if (chatDisplayLog.length === 0) {
    resetAdvisorChat();
  }
});

// Sync product selections and language if changed in another open tab.
window.addEventListener("storage", (event) => {
  if (event.key === "loreal_selected_products") {
    selectedProductIds = loadSavedSelections();
    renderCatalog();
    renderSelectedRoutine();
    updateModalToggleButton();
  } else if (event.key === "loreal_language") {
    applyLanguage(loadSavedLanguage(), false);
  }
});

// Initial render on page load.
applyLanguage(currentLanguage, false);
initializeAdvisorChat();
